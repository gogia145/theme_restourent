<?php
/*
Plugin Name: The Restaurant: Theme specific post types and taxonomies
*/

function rf_theme_init() {

	// Custom post type for sections
	$section_labels = array(
	  'name' => __('Sections', 'the-restaurant'),
	  'singular_name' => __('Sections', 'the-restaurant'),
	  'add_new' => __('Add New', 'the-restaurant'),
	  'add_new_item' => __('Add New Section', 'the-restaurant'),
	  'edit_item' => __('Edit Section', 'the-restaurant'),
	  'new_item' => __('New Section', 'the-restaurant'),
	  'view_item' => __('View Section', 'the-restaurant'),
	  'search_items' => __('Search Sections', 'the-restaurant'),
	  'not_found' =>  __('No Sections found', 'the-restaurant'),
	  'not_found_in_trash' => __('No Sections found in Trash', 'the-restaurant'), 
	  'parent_item_colon' => '',
	  'menu_name' => 'Sections'	,
	  
	);
	$section_args = array(
	  'labels' => $section_labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'exclude_from_search' => true,
	  'show_ui' => true, 
	  'show_in_menu' => true, 
	  'menu_icon' => 'dashicons-section',
	  'query_var' => true,
	  'rewrite' => true,
	  'capability_type' => 'post',
	  'has_archive' => false, 
	  'hierarchical' => false,
	  'menu_position' => 20,
	  'supports' => array('title','thumbnail','editor','custom-fields')
	);
	register_post_type('section',$section_args);



	// Custom post type for Menucard items
	$menucard_labels = array(
	  'name' => __('Menucard item', 'the-restaurant'),
	  'singular_name' => __('Menucard item', 'the-restaurant'),
	  'add_new' => __('Add New Item', 'the-restaurant'),
	  'add_new_item' => __('Add New Item', 'the-restaurant'),
	  'edit_item' => __('Edit Item', 'the-restaurant'),
	  'new_item' => __('New Item', 'the-restaurant'),
	  'view_item' => __('View Item', 'the-restaurant'),
	  'search_items' => __('Search', 'the-restaurant'),
	  'not_found' =>  __('No items found', 'the-restaurant'),
	  'not_found_in_trash' => __('No items found in Trash', 'the-restaurant'), 
	  'parent_item_colon' => '',
	  'menu_name' => 'Menucard items'
	);

	$rf_menucard_slug = 'menucard';

	$menucard_args = array(
	  'labels' => $menucard_labels,
	  'public' => true,
	  'publicly_queryable' => true,
	  'show_ui' => true, 
	  'show_in_menu' => true, 
	  'menu_icon' => 'dashicons-portofolio',
	  'query_var' => true,
	  'rewrite' => array( 'slug' => $rf_menucard_slug ),
	  'capability_type' => 'post',
	  'has_archive' => false, 
	  'hierarchical' => false,
	  'menu_position' => 21,
	  'taxonomies' => array('post_tag'),
	  'supports' => array('title','thumbnail','editor','excerpt','custom-fields')
	); 
	register_post_type('menucard',$menucard_args);



	// create a new taxonomy: Menucard category
	$menucard_cat_labels = array(
		'name'              => _x( 'Menucard category', 'taxonomy general name', 'the-restaurant' ),
		'singular_name'     => _x( 'Menucard category', 'taxonomy singular name', 'the-restaurant' ),
		'search_items'      => __( 'Search categories', 'the-restaurant' ),
		'all_items'         => __( 'All categories', 'the-restaurant' ),
		'parent_item'       => __( 'Parent category', 'the-restaurant' ),
		'parent_item_colon' => __( 'Parent category:', 'the-restaurant' ),
		'edit_item'         => __( 'Edit category', 'the-restaurant' ),
		'update_item'       => __( 'Update category', 'the-restaurant' ),
		'add_new_item'      => __( 'Add New category', 'the-restaurant' ),
		'new_item_name'     => __( 'New category', 'the-restaurant' ),
		'menu_name'         => __( 'Menucard category', 'the-restaurant' ),
	);	
	$menucard_cat_args = array(
		'hierarchical'      => true,
		'labels'            => $menucard_cat_labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'menucardcat' ),
	);
	register_taxonomy( 'menucardcat', array( 'menucard' ), $menucard_cat_args );



	// Custom post type for slides
	$slide_labels = array(
	  'name' => __('Slides', 'the-restaurant'),
	  'singular_name' => __('Slide', 'the-restaurant'),
	  'add_new' => __('Add New Item', 'the-restaurant'),
	  'add_new_item' => __('Add New Item', 'the-restaurant'),
	  'edit_item' => __('Edit Item', 'the-restaurant'),
	  'new_item' => __('New Item', 'the-restaurant'),
	  'view_item' => __('View Item', 'the-restaurant'),
	  'search_items' => __('Search items', 'the-restaurant'),
	  'not_found' =>  __('No items found', 'the-restaurant'),
	  'not_found_in_trash' => __('No items found in Trash', 'the-restaurant'), 
	  'parent_item_colon' => '',
	  'menu_name' => 'Slides' 
	);

	$slide_args = array(
	  'labels' => $slide_labels,
	  'public' => false,
	  'publicly_queryable' => true,
	  'show_ui' => true, 
	  'show_in_menu' => true, 
	  'query_var' => true,
	  'rewrite' => array( 'slug' => 'slide' ),
	  'capability_type' => 'post',
	  'has_archive' => false, 
	  'hierarchical' => false,
	  'menu_position' => 21,
	  'supports' => array('title','thumbnail','custom-fields')
	); 
	register_post_type('slide', $slide_args);
	
}
add_action( 'init', 'rf_theme_init', 5);
?>